import React from 'react';
import { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";

function DrugPage(props) {
    const [Drug, setDrug] = useState([]);

    const {drugid} =useParams ()
    console.log(drugid)
    useEffect(() => {
        const url = `/MyMediForm/drug/${drugid}ّ`;

        const fetchData = async () => {
            try {
                const response = await fetch(url);
                const json = await response.json();
             console.log(JSON.stringify(json));
             setDrug(json)
            } catch (error) {
                console.log("error", error);
            }
        };
          fetchData();
          console.log(Drug)
    
        },     []);


        console.log(Drug)
    return (
        <div>
            {Drug}
                   </div>
    );
}

export default DrugPage;