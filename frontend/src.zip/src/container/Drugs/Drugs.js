import React from 'react';
import { useState, useEffect } from 'react';
import "./drug.css"
import { TextField } from '@mui/material';
import {useNavigate} from 'react-router-dom';


export default  function Drugs() {
//fetch all drugs
        const url = "/MyMediForm/drug/drugs";
        const [Drug, setDrug] = useState([]);
        useEffect(() => {
            const fetchData = async () => {
                try {
                    const response = await fetch(url);
                    const json = await response.json();
        
                 setDrug(json)
                } catch (error) {
                    console.log("error", error);
                }
            };
              fetchData();
              console.log(Drug._id)
        }, []);
// function to 
        const navigate = useNavigate();
      function setparams (){
          navigate(`/drugs/${Drug._id}`)      
        }
        //drug card 
        const listDrug = [...Drug].map((Drug) => 
        <div className="col-12 col-md-4 col-lg-3" key={Drug.id}>
            <div className='card' style={{width: "18rem;"}}>
               {Drug.image? <img src={Drug.image} className="card-img-top" alt="Drug "/>:""}
                <div className="card-body">
                <p  className="card-text" >{Drug.id}</p>
                    <p className="card-text">{Drug.Name}</p>
                    <p className="card-text">{Drug.averrage}</p>
                    <button className='btn' onClick={setparams} style={{color:"pink"} }>المزيد</button>
                </div>
            </div>
        </div>
        );
        const [key,setkey]=useState("")
     
      function Search() {
        if (key.length>0) {
            [...Drug].filter((drugs)=>{
                return drugs.name.includes(key)
            })
        }
    }

    return (
        <div className='drugs'>
       <div className="main">
         <div className="search">
        <TextField id="outlined-basic"   name='key' onChange={(event)=>{setkey(event.target.value)}} fullWidth variant="outlined" label="Search" />     
        </div>
    </div> 
         <div className="row">
         {listDrug}
        
            </div> 
      
            </div>
     )
    }
