import React from "react";
import "./login.css"
import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import { Link } from 'react-router-dom'
import axios from "axios";


export default function Login() {

  const [errorLogin, setErrorLogin] = useState(null)
  const navigate = useNavigate();
const login = async e => {
e.preventDefault()
try {
  const form = e.target
  const emailORusername = form.elements.emailORusername.value
  let userBody
  if (emailORusername.includes("@")) {
    userBody = {
      email: emailORusername,
      password: form.elements.password.value,
    }
  } else
    userBody = {
      username: emailORusername,
      password: form.elements.password.value,
    }

  const response = await axios.post("/MyMediForm/auth/login", userBody)
  const token = response.data
  localStorage.tokenSocial = token

  setErrorLogin(null)
  navigate("/home")
} catch (error) {
  if (error.response) setErrorLogin(error.response.data)
  else console.log(error)
}
}

  return (
    <div>
            
      <div className="herolog"> 
      <div className="form-boxlog">
             <form id="user" className="inputlog"  onSubmit={login}>

             <input type="text"    name="emailORusername" className="input-fieldlog" placeholder="UserName or email " required></input>
             <input type="password" name="password" className="input-fieldlog" placeholder="Enter pass" required></input>
             <button type="submit"   className="submit-btnlog" > {" "}تسجيل الدخول</button>
             <p> ليس لديك حساب؟<Link to="/signup">أنشئ حسابك الآن</Link></p>
             </form>
        </div>
        <div className="">
          <img  className="imglog" alt="no ige"src={require("../../assets/Home/dr4.png")}/>
        </div>
      </div>
    </div>
  );
}
