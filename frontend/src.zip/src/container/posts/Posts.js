import React from 'react';
import { useState, useEffect } from 'react';
function Posts() {
    const [post, setpost] = useState([]);
    useEffect(() => {
        const url = "/MyMediForm/posts/posts";
        const fetchData = async () => {
            try {
                const response = await fetch(url);
                const json = await response.json();
             console.log(JSON.stringify(json));
             setpost(json)
            } catch (error) {
                console.log("error", error);
            }
        };
          fetchData();
          console.log(post)
    
    }, []);
   
    const listpost = [...post].map((post) => 
    <div className="col" key={post.id}>
        <div className='postcard' style={{width: "18rem;"}}>
           
             {post.image?< img src={post.image} className="card-img-top" alt="post"/>:""}
                 
            <div className="card-body">
                <p className="card-text">{post.title}</p>
                <p className="card-text">{post.description}</p>
            </div>
        </div>
    </div>
    );
  

    return (
        <div className='row'>
        <div className='drugs'>
        <div className='posts'>
            {listpost}
            
        </div></div></div>
    );
}

export default Posts;