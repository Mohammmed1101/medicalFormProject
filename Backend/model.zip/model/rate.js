const { Schema, model } = require("mongoose");
const mongoose= require('mongoose');
const Joi = require("joi");
const { number } = require("joi");

const rateSchema = new mongoose.Schema({
   rates:{
    type:Number
   },
   drugid: {
        type: mongoose.Types.ObjectId,
        ref: "drugs"
    },
    owner: {
      type: mongoose.Types.ObjectId,
      ref: "user"
  },
 
})
const rateJoi =(input) => Joi.object({
  rates: Joi.number().min(1).max(5).required(),
}).validate(input)


const rate = mongoose.model("rate", rateSchema)
module.exports.rate = rate
module.exports.rateJoi = rateJoi